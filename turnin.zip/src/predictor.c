//========================================================//
//  predictor.c                                           //
//  Source file for the Branch Predictor                  //
//                                                        //
//  Implement the various branch predictors below as      //
//  described in the README                               //
//========================================================//
#include <stdio.h>
#include "predictor.h"

#define DEBUG 1

//
// Student Information
//
const char *studentName = "Avinash Kondareddy ";
const char *studentID   = "A13074121";
const char *email       = "akondare@ucsd.edu";

//------------------------------------//
//      Predictor Configuration       //
//------------------------------------//

// Handy Global for use in output routines
const char *bpName[4] = { "Static", "Gshare",
                          "Tournament", "Custom" };

int ghistoryBits; // Number of bits used for Global History
int lhistoryBits; // Number of bits used for Local History
int pcIndexBits;  // Number of bits used for PC index
int bpType;       // Branch Prediction Type
int verbose;

//------------------------------------//
//      Predictor Data Structures     //
//------------------------------------//

/*
// calculate size of tables based on number of bits used
int gNum = 1<<ghistoryBits;
int lNum = 1<<lhistoryBits;
int pcNum = 1,<pcIndexxBits;

// initialize glabal history and local history table
int ghr;
int ght[gNum];

int lhr[pcNum];
int lht[lNum];
*/
int ghr;
int * ght;

int * lhr;
int * pht;

int * cht;

unsigned int gMask;
unsigned int lMask;
unsigned int pcMask;

//------------------------------------//
//        Predictor Functions         //
//------------------------------------//

// Initialize the predictor
//
void init_predictor()
{
  int gNum = 1<<ghistoryBits;
  int lNum = 1<<lhistoryBits;
  int pcNum = 1<<pcIndexBits;

  // initialize global history to zero
  ghr = 0;

  // allocate memory for ght, 
  ght = (int *)calloc(gNum, sizeof(int));
  lhr = (int *)calloc(pcNum, sizeof(int));
  pht = (int *)calloc(lNum, sizeof(int));
  cht = (int *)calloc(lNum, sizeof(int));

  // initialize predictions to weakly not taken (01 - two bit)
  for( int i = 0; i < gNum; i++ ) {
    ght[i] = 1;
  }
  for( int i = 0; i < lNum; i++ ) {
    pht[i] = 1;
    cht[i] = 1;
  }

  gMask = ~( (-1) << ghistoryBits );
  lMask = ~( (-1) << pcIndexBits );
  pcMask = ~( (-1) << lhistoryBits );
}

void free_predictor()
{
  free(ght);
  free(lhr);
  free(pht);
  free(cht);
}

// Make a prediction for conditional branch instruction at PC 'pc'
// Returning TAKEN indicates a prediction of taken; returning NOTTAKEN
// indicates a prediction of not taken
//
//
uint8_t make_prediction(uint32_t pc)
{
  switch (bpType) {
    case STATIC:
      return TAKEN;
    case GSHARE:
      return (( ght[(ghr ^ pc) & gMask] ) >> 1);
    case TOURNAMENT:
    case CUSTOM:
    default:
      break;
  }

  // If there is not a compatable bpType then return NOTTAKEN
  return NOTTAKEN;
}

// Train the predictor the last executed branch at PC 'pc' and with
// outcome 'outcome' (true indicates that the branch was taken, false
// indicates that the branch was not taken)
//
void train_gshare(uint32_t pc, uint8_t outcome) {

  int * address = &ght[ (ghr ^ pc) & gMask ];
  int state = *address;

  switch (outcome) {
    case TAKEN:
      if ( state < 3 ) {
        *address = state + 1;
      }
      break;
    case NOTTAKEN:
      if ( state > 0 ) {
        *address = state - 1;
      }
      break;
    default: 
      break;
  }

  ghr = ( (ghr << 1) + outcome ) & gMask;
}

void train_predictor(uint32_t pc, uint8_t outcome) {

  switch (bpType) {

    case STATIC:
      break;
    case GSHARE:
      train_gshare(pc,outcome);
      break;
    case TOURNAMENT:
    case CUSTOM:
    default:
      break;
  }
}
